class Main{

   public static void main (String[] args){
   
   Movie M1 = new Movie ();
   
   M1.title = "Moana";
   M1.genre = "animation";
   M1.duration = 115;
   
   M1.displayInfo();
   
   Movie M2 = new Movie ();
   
   M2.title = "Frozen";
   M2.genre = "animation";
   M2.duration = 110;
   
   M2.displayInfo();
   
   Movie M3 = new Movie ();
   
   M3.title = "Coco";
   M3.genre = "animation";
   M3.duration = 105;
   
   M3.displayInfo();
   
   }
   }